-- QUESTION 1.4

CREATE VIEW vw_InstructorsModules AS
SELECT
    i.instrutorName,
    m.moduleName
FROM INSTRUCTOR i 
INNER JOIN MODULE m 
ON i.instructorID = m.instructorID;