-- QUESTION 1.5

CREATE OR REPLACE PROCEDURE
RegisterStudent
(
    p_studentsNo IN NUMBER,
    p_moduleCode IN VARCHAR2
)
AS
    v_count NUMBER;
BEGIN

    SELECT COUNT(*)
    INTO v_count
    FROM REGISTRATION
    WHERE studentNo = p-studentNo 
    AND moduleCode = p_moduleCode;

    IF v_count = 0 THEN

        INSERT INTO REGISTRATION
        VALUES (p_moduleCode, p_studentNo);

        DBMS_OUTPUT.PUT_LINE
        ('Student successfully registered,');

    ELSE

        DBMS_OUTPUT.PUT_LINE
        ('Student is already registered for this module.');

    END IF;

END;