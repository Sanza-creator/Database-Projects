-- DELIVERABLE 1
-- QUESTION 1.1

CREATE TABLE MODULE(
    moduleCode VARCHAR2(10) PRIMARY KEY,
    moduleName VARCHAR2(100) NOT NULL,
    instructorID NUMBER NOT NULL,
    CONSTRAINT fk_module_instructor FOREIGN KEY (instructorID) REFERENCES INSTRUCTOR(instructorID)
);

CREATE TABLE INSTRUCTOR(
    instructorID NUMBER PRIMARY KEY,
    instructorName VARCHAR2(100) NOT NULL
);

CREATE TABLE STUDENT (
    studentNo NUMBER PRIMARY KEY,
    studentName VARCHAR2(100) NOT NULL
);

CREATE TABLE REGISTRATION(
    moduleCode VARCHAR2(10),
    studentNo NUMBER,
    CONSTRAINT pk_registration PRIMARY KEY (moduleCode, studentNo),
    CONSTRAINT fk_reg_module FOREIGN KEY (moduleCode) REFERENCES MODULE(moduleCode),
    CONSTRAINT fk_reg_student FOREIGN KEY (studentNo) REFERENCES STUDENT(studentNo)
);