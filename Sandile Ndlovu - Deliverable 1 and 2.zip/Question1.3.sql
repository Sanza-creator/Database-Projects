-- QUESTION 1.3

-- INSERT INTO INSTRUCTOR
INSERT INTO INSTRUCTOR 
VALUES (seq_instructor.NEXTAL, 'John Smith');

INSERT INTO INSTRUCTOR 
VALUES (seq_instructor.NEXTVAL, 'Mary Jones');

-- INSERT INTO STUDENT
INSERT INTO STUDENT 
VALUES (seq_student.NEXTVAL, 'Sipho Ndlovu');

INSERT INTO STUDENT 
VALUES (seq_student.NEXTVAL, 'Thando Mokoena');

-- INSERT INTO MODULE
-- (moduleCode = first 3 letters of name + auto number, per scenario)
INSERT INTO MODULE 
VALUES ('DAT1001', 'Database Systems',1);

INSERT INTO MODULE 
VALUES ('PRG002', 'Programming Fundamentals' 2);

-- INSERT INTO REGISTRATION (no sequence - composite PK)
INSERT INTO REGISTRATION 
VALUES ('DAT001', 1001);

INSERT INTO REGISTRATION 
VALUES ('PRG002', 1002);

COMMIT;